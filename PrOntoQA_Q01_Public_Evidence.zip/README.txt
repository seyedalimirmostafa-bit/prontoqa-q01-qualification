PrOntoQA Q01 - public-release candidate RC2
Author: Seyed Ali Mirmostafa
Prepared: 11 October 2026
Status: not published; reuse permissions selected; final author publication approval pending

Purpose and scope
This is a retrospective qualification of one pinned PrOntoQA-OOD generator configuration and a citation-local symbolic scorer. It contains no LLM performance measurement, no demonstrated RSI, no peer-review claim and no established novelty claim. The original qualification stopped because its prespecified relevant-distractor depth-5 supply gate failed. Nothing in this release reopens that investigation.

Contents
- PrOntoQA_Q01_Public_Note.pdf and PrOntoQA_Q01_Public_Note.txt: concise technical note and editable text.
- prontoqa_feasibility_20261010/: public copies of all preserved generation/scoring evidence, including failed attempts, earlier preparation failures, protocols, journals, results, code and source snapshot.
- PROVENANCE.json: original-private and public SHA-256 values, relative names and exact redaction categories.
- SOURCE_VERIFICATION.json: exact official pinned-source comparison for every bundled upstream file.
- MANIFEST.json: byte count and SHA-256 for every other archive member; it cannot include its own hash.
- verify_release.py: standard-library file/record validation only; imports no generator or scorer and makes no network calls.
- Q01_Record_Audit.json and Q01_Independent_Review.txt: retrospective audit and original AI draft reviews.
- RELEASE_REVIEW.txt: current RC2 review and remaining author publication approval gate.
- HISTORY/RELEASE_REVIEW_RC1.txt: unchanged earlier report; its pending-license statement is historical.
- REVISION_CHANGELOG.json and RELEASE_STATUS.json: revision scope and current authorization status.
- INDEPENDENT_SOURCE_VERIFICATION.json: independent fresh comparison of all ten pinned source files.
- LICENSING.txt, LICENSE_MAP.json and NOTICE.txt: explicit grants, file-level scope and attribution.
- LICENSE-CODE-APACHE-2.0.txt and LICENSE-NOTE-CC-BY-4.0.txt: complete standard license texts.

Privacy, provenance and integrity
Only three historical files were changed in their public copies: two traceback filename prefixes in blocked_generation_stderr.txt, and the local Python executable assignment in run_offline_check.ps1 and qualification_01/run_qualification.ps1. Placeholders are <PRIVATE_WORKSPACE> and <PRIVATE_PYTHON_EXECUTABLE>. The source snapshot and all JSON scientific records are unchanged. Seeds, attempt outcomes, counts, failures, timestamps, formulas, fixtures, original verdicts and recorded original hashes remain.

Historical source/harness hashes refer to the original private files. The redacted wrappers have different public hashes, documented in PROVENANCE.json and MANIFEST.json. Do not substitute those new hashes into old result records. Original-file hashes provide an inspectable link to the preserved private originals; they do not prove an external timestamp or disclose the private filesystem. The local seal and journals are not tamper-proof. The original unsanitized ZIP/PDF are not bundled.

1. Validate saved records without reproducing an experiment
Unzip to a new folder. Python 3.9 or newer with its standard library can inspect the records. Run without -O/-OO or PYTHONOPTIMIZE; the validator rejects optimized mode rather than printing a misleading PASS. From the extracted package folder, run:

    python verify_release.py

This only reads files and JSON. Expected output is a successful manifest check, 1,574 attempts / 44 returns / 1,530 rejections in each pass, 3,148 combined attempts, 44 distinct formal keys, identical parsed pass cores and journals, 25 matching fixture expectations, and 44 saved matched pairs. It also checks recorded pair-feature controls and preserves the STOP verdict. No generation, scoring, training or inference occurs.

The validator checks agreement of saved expected/actual fixture fields, recorded pair-feature flags and axiom-multiset equality; it does not reperform entailment or reconstruct every feature fingerprint. The analytic 50% result concerns balanced binary valid/invalid classification using identical paired features, not measured first-error localization. The 5,120-query 2SAT-versus-exhaustive check exists only as a historical aggregate with zero recorded mismatches, plus the source enumeration. Individual comparison rows were not saved. The archive therefore permits aggregate/source reconciliation, not independent replay of those individual historical outcomes without executing the original check anew.

2. Independently inspect the source comparison
Revision: 0a6412b6fddf46324a1cb96e066dd7b3d89b87d6
Official repository: https://github.com/asaparov/prontoqa
Pinned source: https://github.com/asaparov/prontoqa/tree/0a6412b6fddf46324a1cb96e066dd7b3d89b87d6
SOURCE_VERIFICATION.json gives each unauthenticated official raw URL, retrieval time, byte count, SHA-256 and comparison result. All ten bundled files were byte-identical to that revision. Nine were covered by the original source manifest. bad_patterns.txt is additionally verified for release but was not historically manifested.

This is a ten-file snapshot, not a clone of the complete repository. Upstream main is PrOntoQA-OOD; original PrOntoQA is on v1. The Q01 harness extracts only top-level run_experiment.py AST nodes ending before line 666 and removes provider/CLI imports. It executes inspected generator definitions rather than the complete upstream experiment CLI. Do not run run_experiment.py or analyze_results.py as the Q01 reproduction.

3. Optional fresh reproduction - instructions only, not executed for this release
Requirements for the recorded configuration: Windows x64, PowerShell 7, Python 3.12.14 and NumPy 2.3.5 available in that Python runtime. The harness needs only NumPy plus Python's standard library. No provider SDK, SciPy, account, API key or network access is required. Dependency packages and runtimes are not distributed here. The historical full Python build string is in pass1_results.json. A different distribution/build can change provenance fields even when version numbers match; cross-platform or different-build equality has not been established.

Work only in a fresh disposable folder, never in the archived evidence folder. Copy the following while preserving their relative layout:

    reproduction/source_manifest.json
    reproduction/source_snapshot/  (all ten files)
    reproduction/qualification_01/precommit.json
    reproduction/qualification_01/precommit_seal.json
    reproduction/qualification_01/qualification.py
    reproduction/qualification_01/oracle.py
    reproduction/qualification_01/run_qualification.ps1

Do not copy saved pass outputs, journals or launch files into this fresh folder. In this new copy only, replace <PRIVATE_PYTHON_EXECUTABLE> in run_qualification.ps1 with the absolute path of your existing Python executable. Make no other change to the protocol, benchmark, seeds, limits, scorer or wrapper behavior. This local path substitution is a reproduction adaptation; record the adapted launcher's own hash and Python build in your reproduction report.

After reviewing the inspected code and confirming NumPy is available inside that Python runtime, use PowerShell 7:

    pwsh -NoProfile -File reproduction/qualification_01/run_qualification.ps1 -Pass 1
    pwsh -NoProfile -File reproduction/qualification_01/run_qualification.ps1 -Pass 2

The wrapper clears the child environment, uses local TEMP/TMP and PYTHONHASHSEED=0, applies -s -P -B, hides the child window, and imposes a 60-second whole-process cap. The default Windows system directory is C:\Windows. Do not invoke qualification.py directly: that would omit environment clearing and the outer timeout while its output metadata still hardcodes certain launcher assumptions. The Python audit hook is defense in depth for inspected code, not an adversarial OS sandbox; use a credential-free disposable environment with network disabled. No generated executable candidate code is involved.

Expected files in the fresh qualification_01 folder: pass1/pass2 attempt JSONL journals, results JSON, launch JSON, stdout/stderr logs and a local tmp folder. Each launch must exit 0 without timeout, despite the scientific STOP verdict. Expected cells per pass:

    relevant depth 3: 265 attempts, 16 valid returns
    relevant depth 5: 400 attempts, 0 returns
    relevant depth 7: 400 attempts, 0 returns
    none depth 5:     232 attempts, 16 valid returns
    none depth 7:     277 attempts, 12 valid returns

The two fresh pass cores should match each other; runtime/pass-number/outer replay fields are excluded. Compare scientific fields against the archived results separately, documenting any excluded provenance fields: elapsed times, local launch times, full Python build string, and the wrapper hash after path substitution. Do not silently exclude attempt, case, fixture, pair, seed, configuration or gate differences. Any scientific discrepancy is a failed reproduction to report, not a reason for rerolls or changed conditions. Keep all failed outcomes. Do not alter the archived STOP verdict or use this reproduction as authorization for new RSI/LLM work.

4. Attribution and licensing
Upstream snapshot: Apache-2.0; its original LICENSE and notices are retained byte-for-byte. See LICENSING.txt. No upstream NOTICE file was located at this pinned revision. Cite both PrOntoQA papers and this exact source revision. No dependency packages are bundled.

The author selected open reuse on 11 October 2026: original Q01 code/scripts are licensed under Apache-2.0; the note and author-controlled documentation/records are licensed under CC BY 4.0. Upstream snapshot files retain their original Apache-2.0 license and notices. See LICENSING.txt and LICENSE_MAP.json for exact file scope, complete texts and the boundary of author-held rights. Licensing does not create exclusive rights in facts or unprotectable AI-generated material. No dependency packages or third-party papers are regranted. Final author approval of the candidate is still required before publication. The explicit AI-assistance disclosure is in the note and review report. The release reviews were performed by separate AI agents, not independent human peer reviewers.


5. Revision and publication status
RC2 changes licensing/status documentation and regenerates the note PDF. All 41 provenance-mapped historical evidence files remain byte-identical to RC1, including redacted public wrappers and unchanged scientific JSON/JSONL. The prior release review is retained unchanged under HISTORY/. Historical statements about pending rights/approval describe that earlier candidate. The current root LICENSING.txt and RELEASE_STATUS.json govern this candidate. This candidate and its originals have not been published. No upload, repository creation or contact with others is authorized by the license selection.
