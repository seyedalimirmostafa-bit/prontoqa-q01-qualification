"""One bounded smoke check of audited upstream generation; no model calls.

This trusted-code audit hook is defense in depth, not an adversarial OS sandbox.
The unchanged upstream generator/scorer AST is selected explicitly; SciPy,
provider imports, credential entry, experiment dispatch and CLI are not loaded.
"""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import re
import sys
import time
import numpy as np

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source_snapshot'
RUNTIME = Path(sys.base_prefix).resolve()
sys.dont_write_bytecode = True


def audit(event, args):
    if event.startswith(('socket.', 'ctypes.', 'subprocess.')) or event in {
        'os.system', 'os.startfile', 'os.startfile/2', 'os.posix_spawn',
        'os.spawn', 'os.exec', 'marshal.load'}:
        raise PermissionError('Offline source check denies network/native/process access')
    path_events = {'open', 'os.listdir', 'os.scandir', 'os.chdir', 'os.mkdir',
                   'os.remove', 'os.rmdir', 'os.rename', 'os.link', 'os.symlink',
                   'os.chmod', 'os.utime'}
    if event not in path_events:
        return
    positions = (0, 1) if event in {'os.rename', 'os.link', 'os.symlink'} else (0,)
    for position in positions:
        if len(args) <= position or not isinstance(args[position], (str, bytes, os.PathLike)):
            continue
        path = Path(os.fsdecode(args[position])).resolve()
        writing = event not in {'open', 'os.listdir', 'os.scandir'}
        if event == 'open':
            mode, flags = args[1:3]
            writing = (isinstance(mode, str) and any(c in mode for c in 'wax+')) or (
                isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC)))
        if not path.is_relative_to(ROOT) and (writing or not path.is_relative_to(RUNTIME)):
            raise PermissionError('Offline source check denies access outside audit/runtime')


sys.addaudithook(audit)
sys.path.insert(0, str(SOURCE))
# These four source modules contain no I/O or provider imports in the inspected pin.
import fol
import theory
import syntax
import proof

SCORE_NAMES = {'rindex', 'is_antecedent_provable', 'find_premise', 'is_provable',
               'find_path_length', 'parse_reasoning', 'parse_response',
               'decapitalize', 'split_since_formulas', 'evaluate_response'}
tree = ast.parse((SOURCE / 'run_experiment.py').read_text(encoding='utf-8'))
selected = []
for node in tree.body:
    if node.end_lineno < 666:
        if isinstance(node, ast.ImportFrom) and node.module in {'prompt', 'scipy.special'}:
            continue
        if isinstance(node, ast.Import) and any(a.name in {'argparse', 'getpass', 'sys'} for a in node.names):
            continue
        selected.append(node)
    elif isinstance(node, ast.FunctionDef) and node.name in SCORE_NAMES:
        selected.append(node)
    elif isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'acceptable_answers' for t in node.targets):
        selected.append(node)
# No function bodies or initialization statements above are edited.
module_code = compile(ast.Module(body=selected, type_ignores=[]), str(SOURCE / 'run_experiment.py'), 'exec')


def fresh_namespace():
    ns = {'__name__': 'audited_prontoqa_functions'}
    exec(module_code, ns)
    ns['bad_patterns'] = [re.compile(line.strip()) for line in (SOURCE / 'bad_patterns.txt').read_text().splitlines()]
    return ns


def literal(formula):
    sign = True
    if isinstance(formula, fol.FOLNot):
        sign, formula = False, formula.operand
    if not isinstance(formula, fol.FOLFuncApplication) or len(formula.args) != 1:
        raise ValueError('Smoke checker supports unary literals only')
    term = formula.args[0]
    if not isinstance(term, (fol.FOLConstant, fol.FOLVariable)):
        raise ValueError('Unsupported term')
    return (formula.function, sign, term.constant if isinstance(term, fol.FOLConstant) else None)


def closure(axioms):
    """Independent forward-chaining algorithm for the checked unary MP subset."""
    facts, rules = set(), []
    for axiom in axioms:
        if isinstance(axiom, fol.FOLForAll):
            if not isinstance(axiom.operand, fol.FOLIfThen):
                raise ValueError('Unsupported rule')
            antecedent, consequent = literal(axiom.operand.antecedent), literal(axiom.operand.consequent)
            if antecedent[2] is not None or consequent[2] is not None:
                raise ValueError('Expected variable rule')
            rules.append((antecedent[:2], consequent[:2]))
        else:
            facts.add(literal(axiom))
    changed = True
    while changed:
        previous = len(facts)
        for antecedent, consequent in rules:
            for predicate, sign, entity in tuple(facts):
                if (predicate, sign) == antecedent:
                    facts.add((*consequent, entity))
        changed = len(facts) != previous
    return facts


def one_sample(seed, steps):
    ns = fresh_namespace()
    random.seed(seed)
    np.random.seed(seed)
    for attempt in range(1, 101):
        value = ns['generate_question'](steps, None, formula_ordering='random',
            ontology='fictional', distractors='relevant', deduction_rule='ModusPonens',
            proofs_only=False, dfs_mode='none', proof_width=2)
        if value[0] is not None:
            break
    else:
        return {'seed': seed, 'requested_steps_including_axiom': steps,
                'generation_attempts': 100, 'status': 'bounded_generation_exhausted'}
    question, query, axioms, chain, answer, reference = value
    facts = closure(axioms)
    query_lf = ns['parse_sentence'](query.removeprefix('True or false: ').removesuffix('.'), ns['morphology'], False)
    q = literal(query_lf)
    negq = (q[0], not q[1], q[2])
    assert (q in facts) != (negq in facts), 'Unknown or contradictory question'
    assert answer == str(q in facts), 'Independent answer disagreement'
    # Upstream depth counts the initial fact plus inference steps; serialized
    # traces also include the cited universal rule axioms.
    inference_steps = sum(s.step_type != proof.ProofStepType.AXIOM for s in reference)
    assert 1 + inference_steps == steps
    for step in reference:
        assert step.conclusion in axioms or literal(step.conclusion) in facts
    expected = ' '.join(chain) + ' ' + answer
    parsed, label, errors = ns['parse_response'](expected)
    native = ns['evaluate_response'](parsed, label, expected, axioms, False, errors)
    assert not errors and native[0] == 1.0 and native[13], 'Native gold proof check failed'
    # An explicitly contradictory claim is a mechanical oracle test, not AI evidence.
    unsupported = next((s.conclusion for s in reference if s.conclusion not in axioms), None)
    assert unsupported is not None
    bad = unsupported.operand if isinstance(unsupported, fol.FOLNot) else fol.FOLNot(unsupported)
    assert literal(bad) not in facts
    bad_sentence = ns['inflect'](ns['yield_tokens'](ns['formula_to_clause'](bad, ns['morphology'])), end_punctuation='.')
    corrupt_response = ' '.join(chain) + ' ' + bad_sentence + ' ' + answer
    corrupt, corrupt_label, corrupt_errors = ns['parse_response'](corrupt_response)
    corrupt_score = ns['evaluate_response'](corrupt, corrupt_label, expected, axioms, False, corrupt_errors)
    assert not corrupt_errors and corrupt_score[12], 'Native scorer failed to identify injected invalidity'
    _, punctuated_label, _ = ns['parse_response'](expected + '.')
    punctuation_accepted = punctuated_label in ns['acceptable_answers'][answer]
    tail_errors = []
    unterminated = ns['parse_reasoning'](chain[-1].removesuffix('.'), tail_errors)
    return {'status': 'generated_and_checked', 'seed': seed, 'requested_steps_including_axiom': steps,
        'generation_attempts': attempt, 'inference_steps': inference_steps,
        'printed_proof_lines': len(chain), 'question': question, 'query': query,
        'answer': answer, 'reference_reasoning': chain,
        'axioms_tptp': [fol.fol_to_tptp(a) for a in axioms],
        'independent_answer_matches': True, 'native_gold_label_correct': native[0],
        'native_gold_conclusion_found': native[13],
        'injected_invalid_sentence': bad_sentence,
        'native_injected_incorrect_indices': corrupt_score[12],
        'punctuated_label': punctuated_label, 'punctuated_label_accepted': punctuation_accepted,
        'unterminated_reasoning_steps_parsed': len(unterminated),
        'unterminated_reasoning_parse_errors': len(tail_errors)}


started = time.monotonic()
samples = [one_sample(seed, steps) for seed, steps in [(4101, 3), (4102, 5), (4103, 7)]]
repeated = [one_sample(seed, steps) for seed, steps in [(4101, 3), (4102, 5), (4103, 7)]]
assert samples == repeated, 'Fresh-state deterministic replay failed'
guard_probes = {}
for name, action in {
    'outside_file_read': lambda: open(ROOT.parent / 'outside_access_probe.txt'),
    'socket_creation': lambda: __import__('socket').socket(),
    'child_process': lambda: __import__('subprocess').Popen(['blocked-test']),
}.items():
    try:
        action()
    except PermissionError:
        guard_probes[name] = 'blocked'
    else:
        raise AssertionError('Guard probe did not fail closed: ' + name)
hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SOURCE.iterdir()) if p.is_file()}
record = {'revision': '0a6412b6fddf46324a1cb96e066dd7b3d89b87d6',
    'scope': 'DEV mechanical sample only; no protected evaluation generated',
    'python': sys.version, 'numpy': np.__version__, 'scipy_installed': bool(importlib.util.find_spec('scipy')),
    'source_sha256': hashes, 'selected_ast_function_names': sorted(SCORE_NAMES | {'generate_question'}),
    'adapter': 'Unchanged upstream AST; reporting/provider/CLI paths excluded; no dependency stubs',
    'same_process_fresh_state_replay_equal': True, 'samples': samples,
    'independent_checker_scope': 'Unary MP answer closure and reference-conclusion entailment; not full proof-link validation',
    'audit_guard_probes': guard_probes, 'os_security_sandbox': False,
    'host_environment_inherited': False, 'untrusted_candidate_code_executed': False,
    'credentials_accessed': False, 'llm_requests': 0, 'api_spend_usd': '0',
    'scientific_ai_performance_evidence': False, 'elapsed_seconds': time.monotonic() - started}
output = ROOT / ('offline_results.json' if len(sys.argv) == 1 else 'offline_replay_results.json')
output.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'samples': len(samples), 'fresh_state_replay_equal': True,
    'generated_and_checked': sum(s['status'] == 'generated_and_checked' for s in samples),
    'generation_exhaustions': sum(s['status'] == 'bounded_generation_exhausted' for s in samples),
    'guard_probes': guard_probes, 'elapsed_seconds': record['elapsed_seconds'], 'llm_requests': 0}))
