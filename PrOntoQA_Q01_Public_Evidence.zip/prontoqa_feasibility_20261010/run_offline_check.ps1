param([switch]$Replay)
$ErrorActionPreference = 'Stop'
$rsiAuditDirectory = $PSScriptRoot
$rsiPython = '<PRIVATE_PYTHON_EXECUTABLE>'
$rsiTemp = Join-Path $rsiAuditDirectory 'tmp'
New-Item -ItemType Directory -Path $rsiTemp -Force | Out-Null
$rsiStart = [System.Diagnostics.ProcessStartInfo]::new()
$rsiStart.FileName = $rsiPython
$rsiStart.WorkingDirectory = $rsiAuditDirectory
$rsiStart.UseShellExecute = $false
$rsiStart.CreateNoWindow = $true
$rsiStart.RedirectStandardOutput = $true
$rsiStart.RedirectStandardError = $true
$rsiStart.Environment.Clear()
$rsiStart.Environment['SystemRoot'] = 'C:\Windows'
$rsiStart.Environment['WINDIR'] = 'C:\Windows'
$rsiStart.Environment['TEMP'] = $rsiTemp
$rsiStart.Environment['TMP'] = $rsiTemp
$rsiStart.Environment['PYTHONHASHSEED'] = '0'
foreach ($rsiArgument in @('-s','-P','-B',(Join-Path $rsiAuditDirectory 'offline_check.py'))) {
    $rsiStart.ArgumentList.Add($rsiArgument)
}
if ($Replay) { $rsiStart.ArgumentList.Add('replay') }
$rsiProcess = [System.Diagnostics.Process]::Start($rsiStart)
$rsiOutputTask = $rsiProcess.StandardOutput.ReadToEndAsync()
$rsiErrorTask = $rsiProcess.StandardError.ReadToEndAsync()
if (-not $rsiProcess.WaitForExit(15000)) {
    $rsiProcess.Kill($true)
    throw 'Offline check exceeded its 15-second limit.'
}
$rsiOutput = $rsiOutputTask.GetAwaiter().GetResult()
$rsiError = $rsiErrorTask.GetAwaiter().GetResult()
$rsiSuffix = if ($Replay) { 'replay' } else { 'check' }
$rsiOutput | Set-Content -LiteralPath (Join-Path $rsiAuditDirectory ('offline_' + $rsiSuffix + '_stdout.txt')) -Encoding utf8
$rsiError | Set-Content -LiteralPath (Join-Path $rsiAuditDirectory ('offline_' + $rsiSuffix + '_stderr.txt')) -Encoding utf8
if ($rsiOutput) { Write-Output (($rsiOutput -split "`n") | Select-Object -Last 3) }
if ($rsiError) { Write-Output $rsiError }
if ($rsiProcess.ExitCode -ne 0) { throw ('Offline check failed with exit code ' + $rsiProcess.ExitCode) }
