"""Independent, standard-library-only oracle for the frozen Q01 fragment.

Facts are signed ground unary literals (predicate, Boolean sign, entity).
Rules are universally quantified signed unary literal implications.  The
SAT implementation uses an implication graph; the exhaustive cross-check
evaluates assignments directly and does not call the SAT implementation.
This module has no import-time execution, provider access, or file access.
"""

import itertools
import json
import re


def _name(value):
    if (not isinstance(value, str) or not value
            or value != " ".join(value.split())
            or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 _-]*", value) is None):
        raise ValueError("Predicate/entity names must be canonical plain names")
    return value


def _literal(value):
    if not isinstance(value, (tuple, list)) or len(value) != 3:
        raise ValueError("Expected a signed ground unary literal")
    predicate, sign, entity = value
    if type(sign) is not bool:
        raise ValueError("Literal sign must be Boolean")
    return (_name(predicate), sign, _name(entity))


def _rule_literal(value):
    if not isinstance(value, (tuple, list)) or len(value) != 2:
        raise ValueError("Expected a signed unary rule literal")
    predicate, sign = value
    if type(sign) is not bool:
        raise ValueError("Rule-literal sign must be Boolean")
    return (_name(predicate), sign)


def _theory(context, extra_facts=()):
    if not isinstance(context, (tuple, list)):
        raise ValueError("Context must be a sequence of fact/rule dictionaries")
    facts, rules, predicates, entities = [], [], set(), set()
    for axiom in context:
        if not isinstance(axiom, dict):
            raise ValueError("Context axiom must be a dictionary")
        if axiom.get("kind") == "fact" and set(axiom) == {"kind", "literal"}:
            fact = _literal(axiom["literal"])
            facts.append(fact)
            predicates.add(fact[0])
            entities.add(fact[2])
        elif (axiom.get("kind") == "rule"
              and set(axiom) == {"kind", "antecedent", "consequent"}):
            antecedent = _rule_literal(axiom["antecedent"])
            consequent = _rule_literal(axiom["consequent"])
            rules.append((antecedent, consequent))
            predicates.update((antecedent[0], consequent[0]))
        else:
            raise ValueError("Unsupported context schema/formula")
    if not isinstance(extra_facts, (tuple, list)):
        raise ValueError("Extra facts must be a sequence of ground literals")
    for value in extra_facts:
        fact = _literal(value)
        facts.append(fact)
        predicates.add(fact[0])
        entities.add(fact[2])
    # A first-order domain is nonempty, even when no entity is named.
    if not entities:
        entities.add("Q01_DUMMY_ENTITY")
    return facts, rules, sorted(predicates), sorted(entities)


def satisfiable(context, extra_facts=()):
    """Classical satisfiability by iterative implication-graph SCC analysis."""
    facts, rules, predicates, entities = _theory(context, extra_facts)
    atoms = [(predicate, entity) for entity in entities for predicate in predicates]
    atom_index = {atom: index for index, atom in enumerate(atoms)}
    edges = [[] for _ in range(2 * len(atoms))]
    reverse_edges = [[] for _ in edges]

    def node(predicate, sign, entity):
        return 2 * atom_index[(predicate, entity)] + (0 if sign else 1)

    def edge(source, target):
        edges[source].append(target)
        reverse_edges[target].append(source)

    for predicate, sign, entity in facts:
        literal = node(predicate, sign, entity)
        edge(literal ^ 1, literal)
    for antecedent, consequent in rules:
        for entity in entities:
            left = node(antecedent[0], antecedent[1], entity)
            right = node(consequent[0], consequent[1], entity)
            edge(left, right)
            edge(right ^ 1, left ^ 1)

    # Kosaraju's two passes, with explicit stacks to avoid recursion limits.
    seen, order = set(), []
    for start in range(len(edges)):
        if start in seen:
            continue
        seen.add(start)
        stack = [(start, 0)]
        while stack:
            current, next_index = stack[-1]
            if next_index < len(edges[current]):
                successor = edges[current][next_index]
                stack[-1] = (current, next_index + 1)
                if successor not in seen:
                    seen.add(successor)
                    stack.append((successor, 0))
            else:
                order.append(current)
                stack.pop()

    component = [-1] * len(edges)
    identifier = 0
    for start in reversed(order):
        if component[start] != -1:
            continue
        component[start] = identifier
        stack = [start]
        while stack:
            current = stack.pop()
            for predecessor in reverse_edges[current]:
                if component[predecessor] == -1:
                    component[predecessor] = identifier
                    stack.append(predecessor)
        identifier += 1
    return all(component[2 * index] != component[2 * index + 1]
               for index in range(len(atoms)))


def entails(context, goal_tuple):
    """Classical entailment: context and negated goal has no model.

    Inconsistent contexts entail every formula classically.  check_trace
    separately rejects inconsistent original contexts instead of exploiting
    that fact.
    """
    predicate, sign, entity = _literal(goal_tuple)
    return not satisfiable(context, [(predicate, not sign, entity)])


def exhaustive_satisfiable(context, extra_facts=()):
    """Independent truth-assignment oracle, bounded to at most 18 atoms."""
    facts, rules, predicates, entities = _theory(context, extra_facts)
    atoms = [(predicate, entity) for entity in entities for predicate in predicates]
    if len(atoms) > 18:
        raise ValueError("Exhaustive cross-check exceeds its 18-atom limit")
    for values in itertools.product((False, True), repeat=len(atoms)):
        assignment = dict(zip(atoms, values))
        if any(assignment[(predicate, entity)] != sign
               for predicate, sign, entity in facts):
            continue
        violated = False
        for antecedent, consequent in rules:
            for entity in entities:
                if (assignment[(antecedent[0], entity)] == antecedent[1]
                        and assignment[(consequent[0], entity)] != consequent[1]):
                    violated = True
                    break
            if violated:
                break
        if not violated:
            return True
    return False


def _strict_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def _reject_constant(value):
    raise ValueError("Nonstandard JSON constant: " + value)


def _parse_statement(statement, predicates, entities):
    if not isinstance(statement, str):
        raise ValueError("Statement must be text")
    normalized = " ".join(statement.split())
    if normalized.endswith("."):
        normalized = normalized[:-1].rstrip()
    candidates = []
    for entity in entities:
        prefix = entity + " is "
        if not normalized.startswith(prefix):
            continue
        remainder = normalized[len(prefix):]
        sign = True
        if remainder.startswith("not "):
            sign = False
            remainder = remainder[4:]
        if remainder.startswith("a "):
            remainder = remainder[2:]
        elif remainder.startswith("an "):
            remainder = remainder[3:]
        if remainder in predicates:
            candidates.append((remainder, sign, entity))
    if len(candidates) != 1:
        raise ValueError("Unknown vocabulary, ambiguous or unsupported statement")
    return candidates[0]


def check_trace(context, query_tuple, packet_json_string):
    """Score a whole structured trace using the frozen Q01 local semantics.

    Parse failures precede reference failures; both precede inference scoring.
    No invalid assertion is ever inserted into subsequent sound supports.
    A null answer is incorrect when the query has a definite truth value;
    answer_correct is null only if neither query polarity is entailed.
    """
    result = {
        "status": "ok", "first_unsupported": None, "failure_kind": None,
        "globally_entailed": None, "complete": False,
        "answer_correct": None, "detail": None,
    }
    try:
        query = _literal(query_tuple)
        facts, rules, predicates, entities = _theory(context, [query])
        # Adding query above is only for vocabulary/grounding, not an axiom.
        if not satisfiable(context):
            raise ValueError("Original context is inconsistent")
    except (ValueError, TypeError) as error:
        result.update(status="context_error", detail=str(error))
        return result

    try:
        if not isinstance(packet_json_string, str):
            raise ValueError("Packet must be a complete JSON string")
        packet = json.loads(packet_json_string, object_pairs_hook=_strict_object,
                            parse_constant=_reject_constant)
        if not isinstance(packet, dict) or set(packet) != {"claims", "answer"}:
            raise ValueError("Packet keys must be exactly claims and answer")
        if not isinstance(packet["claims"], list):
            raise ValueError("Claims must be a list")
        if packet["answer"] is not None and type(packet["answer"]) is not bool:
            raise ValueError("Answer must be Boolean or null")
        parsed_claims = []
        for claim in packet["claims"]:
            if not isinstance(claim, dict) or set(claim) != {"statement", "support"}:
                raise ValueError("Claim keys must be exactly statement and support")
            literal = _parse_statement(claim["statement"], predicates, entities)
            if not isinstance(claim["support"], list):
                raise ValueError("Claim support must be a citation list")
            parsed_claims.append((literal, claim["support"]))
    except (ValueError, TypeError) as error:
        result.update(status="parse_error", detail=str(error))
        return result

    references = []
    try:
        for one_based_index, (_, supports) in enumerate(parsed_claims, 1):
            if not supports:
                raise ValueError("Missing citation at claim " + str(one_based_index))
            seen = set()
            claim_references = []
            for support in supports:
                if not isinstance(support, str):
                    raise ValueError("Citation must be text")
                match = re.fullmatch(r"(axiom|claim):([1-9][0-9]*)", support)
                if match is None:
                    raise ValueError("Malformed citation: " + support)
                if support in seen:
                    raise ValueError("Duplicate citation: " + support)
                seen.add(support)
                kind, number_text = match.groups()
                number = int(number_text)
                if kind == "axiom" and number > len(context):
                    raise ValueError("Missing context axiom: " + support)
                if kind == "claim" and number >= one_based_index:
                    raise ValueError("Missing or future claim: " + support)
                claim_references.append((kind, number))
            references.append(claim_references)
    except (ValueError, TypeError) as error:
        result.update(status="reference_error", detail=str(error))
        return result

    negated_query = (query[0], not query[1], query[2])
    if entails(context, query):
        expected_answer = True
    elif entails(context, negated_query):
        expected_answer = False
    else:
        expected_answer = None
    if expected_answer is not None:
        result["answer_correct"] = packet["answer"] is expected_answer

    sound_claims = {}
    for one_based_index, ((literal, _), supports) in enumerate(
            zip(parsed_claims, references), 1):
        support_theory = []
        for kind, number in supports:
            if kind == "axiom":
                support_theory.append(context[number - 1])
            else:
                # All referenced earlier claims are sound until the first
                # unsupported claim, where this loop immediately stops.
                support_theory.append({"kind": "fact", "literal": sound_claims[number]})
        if not entails(support_theory, literal):
            globally_entailed = entails(context, literal)
            result.update(
                first_unsupported=one_based_index,
                failure_kind="bad_justification" if globally_entailed else "unsupported_claim",
                globally_entailed=globally_entailed,
            )
            return result
        sound_claims[one_based_index] = literal
    result["complete"] = any(literal in (query, negated_query)
                             for literal in sound_claims.values())
    return result
