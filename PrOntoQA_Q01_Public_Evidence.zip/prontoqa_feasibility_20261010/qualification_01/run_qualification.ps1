param([ValidateSet(1,2)][int]$Pass = 1)
$ErrorActionPreference = 'Stop'
$rsiAuditDirectory = $PSScriptRoot
$rsiPython = '<PRIVATE_PYTHON_EXECUTABLE>'
$rsiTemp = Join-Path $rsiAuditDirectory 'tmp'
New-Item -ItemType Directory -Path $rsiTemp -Force | Out-Null
$rsiRecordPath = Join-Path $rsiAuditDirectory ('pass' + $Pass + '_launch.json')
if (Test-Path -LiteralPath $rsiRecordPath) { throw 'Pass already launched; no rerun authorized.' }
$rsiLaunch = @{ pass=$Pass; started_utc=[DateTime]::UtcNow.ToString('o'); timeout_seconds=60; clean_environment=$true }
$rsiLaunch | ConvertTo-Json | Set-Content -LiteralPath $rsiRecordPath -Encoding utf8
$rsiStart = [System.Diagnostics.ProcessStartInfo]::new()
$rsiStart.FileName = $rsiPython
$rsiStart.WorkingDirectory = $rsiAuditDirectory
$rsiStart.UseShellExecute = $false
$rsiStart.CreateNoWindow = $true
$rsiStart.RedirectStandardOutput = $true
$rsiStart.RedirectStandardError = $true
$rsiStart.Environment.Clear()
$rsiStart.Environment['SystemRoot'] = 'C:\Windows'
$rsiStart.Environment['WINDIR'] = 'C:\Windows'
$rsiStart.Environment['TEMP'] = $rsiTemp
$rsiStart.Environment['TMP'] = $rsiTemp
$rsiStart.Environment['PYTHONHASHSEED'] = '0'
foreach ($rsiArgument in @('-s','-P','-B',(Join-Path $rsiAuditDirectory 'qualification.py'),[string]$Pass)) {
    $rsiStart.ArgumentList.Add($rsiArgument)
}
$rsiProcess = [System.Diagnostics.Process]::Start($rsiStart)
$rsiOutputTask = $rsiProcess.StandardOutput.ReadToEndAsync()
$rsiErrorTask = $rsiProcess.StandardError.ReadToEndAsync()
$rsiTimedOut = -not $rsiProcess.WaitForExit(60000)
if ($rsiTimedOut) { $rsiProcess.Kill($true); $rsiProcess.WaitForExit() }
$rsiOutput = $rsiOutputTask.GetAwaiter().GetResult()
$rsiError = $rsiErrorTask.GetAwaiter().GetResult()
$rsiOutput | Set-Content -LiteralPath (Join-Path $rsiAuditDirectory ('pass' + $Pass + '_stdout.txt')) -Encoding utf8
$rsiError | Set-Content -LiteralPath (Join-Path $rsiAuditDirectory ('pass' + $Pass + '_stderr.txt')) -Encoding utf8
$rsiLaunch['timed_out'] = $rsiTimedOut
$rsiLaunch['exit_code'] = $rsiProcess.ExitCode
$rsiLaunch['finished_utc'] = [DateTime]::UtcNow.ToString('o')
$rsiLaunch | ConvertTo-Json | Set-Content -LiteralPath $rsiRecordPath -Encoding utf8
if ($rsiOutput) { Write-Output $rsiOutput }
if ($rsiError) { Write-Output $rsiError }
if ($rsiTimedOut) { throw 'Frozen 60-second qualification limit reached; no extension.' }
if ($rsiProcess.ExitCode -ne 0) { throw ('Qualification failed with exit code ' + $rsiProcess.ExitCode) }
