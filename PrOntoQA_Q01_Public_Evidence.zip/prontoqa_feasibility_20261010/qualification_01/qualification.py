"""Execute exactly the frozen Q01 qualification and its registered replay.

Only audited, unchanged upstream generator AST is loaded. No provider imports,
CLI, credential code, upstream experimental dispatch or protected cases run.
This defense-in-depth audit hook is not an adversarial OS sandbox.
"""
import ast
from collections import Counter, deque
from contextlib import redirect_stdout
import hashlib
import io
import itertools
import json
import os
from pathlib import Path
import random
import re
import sys
import time
import traceback
import numpy as np

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "source_snapshot"
RUNTIME = Path(sys.base_prefix).resolve()
sys.dont_write_bytecode = True


def audit(event, args):
    if event.startswith(("socket.", "ctypes.", "subprocess.")) or event in {
            "os.system", "os.startfile", "os.startfile/2", "os.posix_spawn",
            "os.spawn", "os.exec", "marshal.load"}:
        raise PermissionError("Q01 denies network/native/process access")
    path_events = {"open", "os.listdir", "os.scandir", "os.chdir", "os.mkdir",
                   "os.remove", "os.rmdir", "os.rename", "os.link", "os.symlink",
                   "os.chmod", "os.utime"}
    if event not in path_events:
        return
    positions = (0, 1) if event in {"os.rename", "os.link", "os.symlink"} else (0,)
    for position in positions:
        if len(args) <= position or not isinstance(args[position], (str, bytes, os.PathLike)):
            continue
        path = Path(os.fsdecode(args[position])).resolve()
        writing = event not in {"open", "os.listdir", "os.scandir"}
        if event == "open":
            mode, flags = args[1:3]
            writing = (isinstance(mode, str) and any(c in mode for c in "wax+")) or (
                isinstance(flags, int) and bool(flags & (
                    os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC)))
        readable = (path.is_relative_to(ROOT) or path.is_relative_to(SOURCE)
                    or path.is_relative_to(RUNTIME)
                    or path == ROOT.parent / "source_manifest.json")
        if (writing and not path.is_relative_to(ROOT)) or (not writing and not readable):
            raise PermissionError("Q01 denies file access outside qualification/source/runtime")


sys.addaudithook(audit)
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(SOURCE))
import oracle


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def fact(predicate, sign=True, entity="Sam"):
    return {"kind": "fact", "literal": (predicate, sign, entity)}


def rule(left, right, left_sign=True, right_sign=True):
    return {"kind": "rule", "antecedent": (left, left_sign), "consequent": (right, right_sign)}


def statement(literal):
    return literal[2] + " is " + ("" if literal[1] else "not ") + literal[0] + "."


def claim(text, *supports):
    return {"statement": text, "support": list(supports)}


def packet(claims, answer=True):
    return {"claims": claims, "answer": answer}


def scorer_fixtures():
    context = [fact("alpha"), rule("alpha", "beta"), rule("beta", "gamma"),
               fact("delta"), rule("delta", "gamma")]
    query = ("gamma", True, "Sam")
    gold = [claim("Sam is alpha.", "axiom:1"),
            claim("Sam is beta.", "claim:1", "axiom:2"),
            claim("Sam is gamma.", "claim:2", "axiom:3")]
    records = []

    def check(name, ctx, q, data, **expected):
        text = data if isinstance(data, str) else canonical(data)
        actual = oracle.check_trace(ctx, q, text)
        records.append({"name": name, "context": ctx, "query": q, "packet": text,
                        "expected": expected, "actual": actual,
                        "pass": all(actual.get(k) == v for k, v in expected.items())})

    sound = {"status": "ok", "first_unsupported": None, "complete": True, "answer_correct": True}
    check("valid_reference", context, query, packet(gold), **sound)
    check("valid_alternative_path", context, query, packet([
        claim("Sam is delta.", "axiom:4"), claim("Sam is gamma.", "claim:1", "axiom:5")]), **sound)
    check("valid_off_reference_claim", context, query, packet(gold + [claim("Sam is delta.", "axiom:4")]), **sound)
    check("valid_multihop_shortcut", context, query,
          packet([claim("Sam is gamma.", "axiom:1", "axiom:2", "axiom:3")]), **sound)
    check("valid_contraposition", [rule("alpha", "beta"), fact("beta", False)],
          ("alpha", False, "Sam"), packet([claim("Sam is not alpha.", "axiom:1", "axiom:2")]), **sound)
    check("invalid_converse", [rule("alpha", "beta"), fact("beta")], ("alpha", True, "Sam"),
          packet([claim("Sam is alpha.", "axiom:1", "axiom:2")]), status="ok", first_unsupported=1,
          failure_kind="unsupported_claim", globally_entailed=False, complete=False)
    check("invalid_denying_antecedent", [rule("alpha", "beta"), fact("alpha", False)],
          ("beta", False, "Sam"), packet([claim("Sam is not beta.", "axiom:1", "axiom:2")]),
          status="ok", first_unsupported=1, failure_kind="unsupported_claim", globally_entailed=False)
    check("globally_true_bad_citation", context, query, packet([
        gold[0], claim("Sam is beta.", "axiom:2"), gold[2]]), status="ok", first_unsupported=2,
          failure_kind="bad_justification", globally_entailed=True, complete=False, answer_correct=True)
    check("unsupported_claim", context, query, packet([
        claim("Sam is not alpha.", "axiom:1")]), status="ok", first_unsupported=1,
          failure_kind="unsupported_claim", globally_entailed=False, complete=False)
    check("incomplete_trace", context, query, packet(gold[:-1]), status="ok",
          first_unsupported=None, complete=False, answer_correct=True)
    check("empty_trace", context, query, packet([], None), status="ok",
          first_unsupported=None, complete=False, answer_correct=False)
    check("wrong_answer_sound_proof", context, query, packet(gold, False), status="ok",
          first_unsupported=None, complete=True, answer_correct=False)
    for name, supports in [("future_citation", ["claim:2"]), ("missing_citation", []),
                           ("missing_axiom", ["axiom:99"]), ("duplicate_citation", ["axiom:1", "axiom:1"])]:
        check(name, context, query, packet([claim("Sam is alpha.", *supports)]),
              status="reference_error", first_unsupported=None)
    check("malformed_json", context, query, '{"claims": [', status="parse_error", first_unsupported=None)
    check("trailing_text", context, query, canonical(packet(gold)) + " extra", status="parse_error", first_unsupported=None)
    check("unsupported_formula", context, query, packet([claim("Sam is alpha and beta.", "axiom:1")]),
          status="parse_error", first_unsupported=None)
    check("unknown_vocabulary", context, query, packet([claim("Sam is zeta.", "axiom:1")]),
          status="parse_error", first_unsupported=None)
    check("duplicate_json_key", context, query, '{"claims":[],"answer":true,"answer":false}',
          status="parse_error", first_unsupported=None)
    varied = json.loads(canonical(packet(gold)))
    for c in varied["claims"]:
        c["statement"] = "  " + c["statement"].removesuffix(".").replace(" is ", "\n is   ") + "  "
    check("punctuation_whitespace", context, query, "\n" + json.dumps(varied, indent=2) + " \n", **sound)
    check("inconsistent_context", [fact("alpha"), fact("alpha", False)], ("alpha", True, "Sam"),
          packet([claim("Sam is alpha.", "axiom:1")]), status="context_error", first_unsupported=None)
    # Same trace and word multiset, but different global entailment.
    valid = [fact("alpha"), rule("alpha", "beta"), rule("beta", "gamma"), rule("delta", "epsilon")]
    invalid = [fact("alpha"), rule("alpha", "epsilon"), rule("beta", "gamma"), rule("delta", "beta")]
    check("matched_global_valid", valid, query, packet(gold), **sound)
    check("matched_global_invalid", invalid, query, packet(gold), status="ok", first_unsupported=2,
          failure_kind="unsupported_claim", globally_entailed=False, complete=False)
    word_bag_equal = Counter(re.findall(r"[A-Za-z0-9]+", canonical(valid))) == Counter(
        re.findall(r"[A-Za-z0-9]+", canonical(invalid)))
    return {"records": records, "hand_context_word_bag_equal": word_bag_equal,
            "pass": word_bag_equal and all(r["pass"] for r in records)}


def exhaustive_crosscheck():
    literals = [(p, s) for p in ("alpha", "beta") for s in (False, True)]
    implications = [(left, right) for left in literals for right in literals]
    mismatches = []
    count = 0
    for first, second in itertools.product(implications, repeat=2):
        for given in [None] + literals:
            ctx = [{"kind": "rule", "antecedent": a, "consequent": b} for a, b in (first, second)]
            if given is not None:
                ctx.append(fact(given[0], given[1]))
            graph_sat = oracle.satisfiable(ctx)
            enumeration_sat = oracle.exhaustive_satisfiable(ctx)
            for p, s in literals:
                q = (p, s, "Sam")
                graph = oracle.entails(ctx, q)
                enumeration = not oracle.exhaustive_satisfiable(ctx, [(p, not s, "Sam")])
                count += 1
                if graph_sat != enumeration_sat or graph != enumeration:
                    mismatches.append({"context": ctx, "query": q, "graph": graph, "enumeration": enumeration})
    return {"comparisons": count, "mismatches": mismatches, "pass": count == 5120 and not mismatches}


def from_fol_literal(formula, variable=None):
    sign = True
    if isinstance(formula, fol.FOLNot):
        sign, formula = False, formula.operand
    if not isinstance(formula, fol.FOLFuncApplication) or len(formula.args) != 1:
        raise ValueError("Formula outside signed unary fragment")
    term = formula.args[0]
    if variable is None:
        if not isinstance(term, fol.FOLConstant):
            raise ValueError("Expected a ground literal")
        return (formula.function, sign, term.constant)
    if not isinstance(term, fol.FOLVariable) or term.variable != variable:
        raise ValueError("Mismatched quantified variable")
    return (formula.function, sign)


def from_fol(formula):
    if isinstance(formula, fol.FOLForAll):
        if not isinstance(formula.operand, fol.FOLIfThen):
            raise ValueError("Unsupported quantified formula")
        return {"kind": "rule", "antecedent": from_fol_literal(formula.operand.antecedent, formula.variable),
                "consequent": from_fol_literal(formula.operand.consequent, formula.variable)}
    return {"kind": "fact", "literal": from_fol_literal(formula)}


def mp_distance(ctx, goal):
    distance, agenda = {}, deque()
    for axiom in ctx:
        if axiom["kind"] == "fact":
            lit = tuple(axiom["literal"])
            distance[lit] = 0
            agenda.append(lit)
    while agenda:
        lit = agenda.popleft()
        for axiom in ctx:
            if axiom["kind"] == "rule" and tuple(axiom["antecedent"]) == lit[:2]:
                successor = (*axiom["consequent"], lit[2])
                if successor not in distance:
                    distance[successor] = distance[lit] + 1
                    agenda.append(successor)
    return distance.get(goal)


def structural_summary(ctx):
    # Coarse signature only: do not claim graph isomorphism or independent families.
    indegree, outdegree = Counter(), Counter()
    facts, negative = 0, 0
    for ax in ctx:
        if ax["kind"] == "rule":
            a, b = tuple(ax["antecedent"]), tuple(ax["consequent"])
            outdegree[a] += 1
            indegree[b] += 1
            negative += int(not a[1]) + int(not b[1])
        else:
            facts += 1
            negative += int(not ax["literal"][1])
    nodes = set(indegree) | set(outdegree)
    return {"fact_count": facts, "rule_count": sum(outdegree.values()),
            "signed_node_count": len(nodes), "negative_occurrences": negative,
            "degree_pairs": sorted((indegree[n], outdegree[n]) for n in nodes)}


def inspect_case(value, ns, depth, case_id):
    question, query_text, axioms, chain, answer, reference = value
    ctx = [from_fol(a) for a in axioms]
    qf = ns["parse_sentence"](query_text.removeprefix("True or false: ").removesuffix("."), ns["morphology"], False)
    q = from_fol_literal(qf)
    goal = (q[0], q[1] if answer == "True" else not q[1], q[2])
    claims, ids, inference_rule_ids = [], {}, []
    for step in reference:
        if isinstance(step.conclusion, fol.FOLForAll):
            if step.step_type != proof.ProofStepType.AXIOM or step.conclusion not in axioms:
                raise ValueError("Rule proof line is not a context axiom")
            continue
        lit = from_fol_literal(step.conclusion)
        supports = []
        if step.step_type == proof.ProofStepType.AXIOM:
            supports.append("axiom:" + str(axioms.index(step.conclusion) + 1))
        elif step.step_type == proof.ProofStepType.UNIVERSAL_INSTANTIATION:
            for premise in step.premises:
                if isinstance(premise.conclusion, fol.FOLForAll):
                    number = axioms.index(premise.conclusion) + 1
                    supports.append("axiom:" + str(number))
                    inference_rule_ids.append(number)
                else:
                    if id(premise) not in ids:
                        raise ValueError("Proof references a non-earlier ground premise")
                    supports.append("claim:" + str(ids[id(premise)]))
        else:
            raise ValueError("Unexpected reference inference type")
        claims.append(claim(statement(lit), *supports))
        ids[id(step)] = len(claims)
    pkt = packet(claims, answer == "True")
    score = oracle.check_trace(ctx, q, canonical(pkt))
    reference_count = sum(s.step_type != proof.ProofStepType.AXIOM for s in reference)
    distance = mp_distance(ctx, goal)
    checks = {"consistent": oracle.satisfiable(ctx),
              "ground_truth": answer in ("True", "False") and oracle.entails(ctx, goal)
                  and not oracle.entails(ctx, (goal[0], not goal[1], goal[2])),
              "exact_reference_depth": reference_count + 1 == depth,
              "minimum_mp_depth": distance is not None and distance >= depth - 1,
              "sound_complete_trace": score["status"] == "ok" and score["first_unsupported"] is None
                  and score["complete"] and score["answer_correct"]}
    unique_key = digest({"context": sorted((canonical(a) for a in ctx)), "query": q})
    return {"case_id": case_id, "question": question, "query_text": query_text, "answer": answer,
            "native_chain": chain, "axioms_tptp": [fol.fol_to_tptp(a) for a in axioms],
            "context": ctx, "query": q, "trace": pkt, "trace_score": score,
            "reference_inferences": reference_count, "shortest_mp_inferences": distance,
            "inference_rule_ids": inference_rule_ids, "unique_key": unique_key,
            "coarse_structure": structural_summary(ctx), "checks": checks, "pass": all(checks.values())}


def generated_pair(case, ordinal):
    rules = case["inference_rule_ids"]
    if len(rules) < 2:
        return {"case_id": case["case_id"], "pass": False, "reason": "Fewer than two inference rules"}
    offset = ordinal % (len(rules) - 1)
    left, right = rules[offset] - 1, rules[offset + 1] - 1
    altered = list(case["context"])
    altered[left], altered[right] = altered[right], altered[left]
    text = canonical(case["trace"])
    valid = oracle.check_trace(case["context"], case["query"], text)
    invalid = oracle.check_trace(altered, case["query"], text)
    bag_equal = Counter(re.findall(r"[A-Za-z0-9]+", canonical(case["context"]))) == Counter(
        re.findall(r"[A-Za-z0-9]+", canonical(altered)))
    # All trace features, including support IDs/distances, are identical by construction.
    features = {"context_word_bag": sorted(Counter(re.findall(r"[A-Za-z0-9]+", canonical(altered))).items()),
                "entire_trace": text}
    return {"case_id": case["case_id"], "valid_context": case["context"], "invalid_context": altered,
            "query": case["query"], "identical_trace": text, "swapped_one_based_axioms": [left + 1, right + 1],
            "valid_score": valid, "invalid_score": invalid, "context_word_bag_equal": bag_equal,
            "feature_fingerprint": digest(features),
            "pass": bag_equal and valid["status"] == "ok" and valid["first_unsupported"] is None
                and valid["complete"] and invalid["status"] == "ok"
                and invalid["first_unsupported"] is not None and invalid["globally_entailed"] is True}


def main():
    global fol, proof
    started = time.monotonic()
    if len(sys.argv) != 2 or sys.argv[1] not in ("1", "2"):
        raise ValueError("Pass must be exactly 1 or registered replay 2")
    pass_number = int(sys.argv[1])
    output = ROOT / ("pass" + str(pass_number) + "_results.json")
    attempts_path = ROOT / ("pass" + str(pass_number) + "_attempts.jsonl")
    if output.exists() or attempts_path.exists():
        raise RuntimeError("Qualification pass already started; refusing to overwrite or rerun")
    frozen_bytes = (ROOT / "precommit.json").read_bytes()
    seal = json.loads((ROOT / "precommit_seal.json").read_text())
    if hashlib.sha256(frozen_bytes).hexdigest() != seal["precommit_sha256"]:
        raise RuntimeError("Frozen precommit hash mismatch")
    registered = json.loads(frozen_bytes)
    manifest = json.loads((ROOT.parent / "source_manifest.json").read_text())
    source_hashes = {}
    for entry in manifest["files"]:
        measured = hashlib.sha256((SOURCE / entry["file"]).read_bytes()).hexdigest()
        if measured != entry["sha256"]:
            raise RuntimeError("Pinned source hash mismatch: " + entry["file"])
        source_hashes[entry["file"]] = measured
    # Verify pinned source before executing even its dependency modules.
    import fol
    import proof
    tree = ast.parse((SOURCE / "run_experiment.py").read_text(encoding="utf-8"))
    selected = []
    for node in tree.body:
        if node.end_lineno >= 666:
            continue
        if isinstance(node, ast.ImportFrom) and node.module in {"prompt", "scipy.special"}:
            continue
        if isinstance(node, ast.Import) and any(a.name in {"argparse", "getpass", "sys"} for a in node.names):
            continue
        selected.append(node)
    compiled = compile(ast.Module(body=selected, type_ignores=[]), str(SOURCE / "run_experiment.py"), "exec")
    attempts, cases, cells = [], [], []
    with attempts_path.open("x", encoding="utf-8") as journal:
        for configuration in registered["configurations"]:
            for depth in configuration["depths"]:
                cell_cases, stream_records = [], []
                for base_seed in registered["base_seeds"]:
                    returned, valid, stream_attempts = 0, 0, 0
                    for attempt in range(1, registered["maximum_attempts_per_stream_cell"] + 1):
                        if time.monotonic() - started > registered["maximum_wall_seconds_per_pass"]:
                            raise TimeoutError("Frozen pass wall limit reached; no extension")
                        seed = base_seed * 1000 + attempt
                        record = {"configuration": configuration["id"], "depth": depth,
                                  "base_seed": base_seed, "attempt": attempt, "seed": seed}
                        captured = io.StringIO()
                        try:
                            with redirect_stdout(captured):
                                ns = {"__name__": "q01_audited_generator"}
                                exec(compiled, ns)
                                random.seed(seed)
                                np.random.seed(seed)
                                value = ns["generate_question"](depth, None, formula_ordering="random",
                                    ontology="fictional", distractors=configuration["distractors"],
                                    deduction_rule="ModusPonens", proofs_only=False,
                                    dfs_mode="none", proof_width=2, no_adjectives=False)
                            if value[0] is None:
                                record["status"] = "rejected"
                            else:
                                returned += 1
                                record["status"] = "returned"
                                # Persist upstream outputs even if the independent adapter/checker fails.
                                record["upstream_output"] = {"question": value[0], "query": value[1],
                                    "axioms_tptp": [fol.fol_to_tptp(a) for a in value[2]],
                                    "native_chain": value[3], "answer": value[4],
                                    "reference_types": [str(s.step_type) for s in value[5]]}
                                case_id = configuration["id"] + "_d" + str(depth) + "_s" + str(seed)
                                case = inspect_case(value, ns, depth, case_id)
                                record["case_id"] = case_id
                                record["checks"] = case["checks"]
                                cases.append(case)
                                cell_cases.append(case)
                                valid += int(case["pass"])
                        except Exception as error:
                            record["status"] = "returned_check_error" if "upstream_output" in record else "exception"
                            record["error"] = type(error).__name__ + ": " + str(error)
                            record["traceback"] = traceback.format_exc()
                        record["upstream_stdout"] = captured.getvalue()
                        attempts.append(record)
                        journal.write(canonical(record) + "\n")
                        journal.flush()
                        stream_attempts += 1
                        if returned >= registered["returned_examples_target_per_stream_cell"]:
                            break
                    stream_records.append({"base_seed": base_seed, "attempts": stream_attempts,
                                           "returned": returned, "valid": valid})
                cell = {"configuration": configuration["id"], "depth": depth, "streams": stream_records,
                        "returned": sum(s["returned"] for s in stream_records),
                        "valid": sum(s["valid"] for s in stream_records),
                        "unique_valid": len({c["unique_key"] for c in cell_cases if c["pass"]}),
                        "successful_streams": sum(s["valid"] > 0 for s in stream_records),
                        "coarse_structure_count": len({digest(c["coarse_structure"]) for c in cell_cases}),
                        "attempts": sum(s["attempts"] for s in stream_records)}
                cells.append(cell)
                print(canonical(cell), flush=True)
    fixtures = scorer_fixtures()
    exhaustive = exhaustive_crosscheck()
    pairs = [generated_pair(c, i) for i, c in enumerate(cases)]
    # Any deterministic classifier using only these identical paired features
    # necessarily predicts the same class twice, so exactly one label is right.
    feature_classifier_accuracy = sum(1 for p in pairs if p["pass"]) / (2 * len(pairs)) if pairs else None
    all_outputs_valid = (all(c["pass"] for c in cases)
                         and not any(a["status"] in {"exception", "returned_check_error"} for a in attempts))
    supply = []
    for cell in cells:
        minimum = 12 if cell["configuration"] == "supported_none" else (8 if cell["depth"] == 5 else None)
        if minimum is not None:
            supply.append({"configuration": cell["configuration"], "depth": cell["depth"],
                           "minimum_unique": minimum, "pass": cell["unique_valid"] >= minimum
                               and cell["successful_streams"] >= 3})
    core = {"precommit_sha256": seal["precommit_sha256"], "source_hashes": source_hashes,
            "qualification_engine_hashes": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                                            for name in ("qualification.py", "oracle.py", "run_qualification.ps1")},
            "python": sys.version, "numpy": np.__version__, "attempts": attempts, "cases": cases,
            "cells": cells, "fixtures": fixtures, "exhaustive": exhaustive, "matched_pairs": pairs,
            "feature_classifier_accuracy": feature_classifier_accuracy, "supply_gates": supply,
            "gates": {"all_outputs_valid": all_outputs_valid, "supply": all(s["pass"] for s in supply),
                      "scorer": fixtures["pass"] and exhaustive["pass"],
                      "artifacts": len(pairs) >= 12 and all(p["pass"] for p in pairs)
                          and feature_classifier_accuracy == 0.5}}
    replay_equal = None
    if pass_number == 2:
        first = json.loads((ROOT / "pass1_results.json").read_text(encoding="utf-8"))
        replay_equal = canonical(core) == canonical(first["core"])
    local_gates = all(core["gates"].values())
    result = {"core": core, "pass_number": pass_number, "elapsed_seconds": time.monotonic() - started,
              "replay_equal": replay_equal, "scope": "DEV mechanical qualification only",
              "host_environment_inherited": False, "os_security_sandbox": False,
              "untrusted_candidate_code_executed": False, "llm_requests": 0, "api_spend_usd": "0",
              "protected_evaluation_generated": False,
              "verdict": ("GO TO SEPARATELY APPROVED LLM PILOT" if local_gates and replay_equal is True
                          else "STOP CURRENT QUALIFICATION" if not local_gates or replay_equal is False
                          else "AWAIT REGISTERED REPLAY")}
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(canonical({k: result[k] for k in ("pass_number", "elapsed_seconds", "replay_equal", "verdict")}
                    | {"gates": core["gates"], "generator_invocations": len(attempts), "cases": len(cases),
                       "fixtures": len(fixtures["records"]), "exhaustive_comparisons": exhaustive["comparisons"]}), flush=True)


if __name__ == "__main__":
    main()
