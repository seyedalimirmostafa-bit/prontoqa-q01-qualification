"""Read-only validation of public package hashes and saved Q01 records.
No generator/scorer import, execution, network, subprocess or writes.
"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import sys

if sys.version_info < (3,9):
    raise RuntimeError('Saved-record validation requires Python 3.9 or newer.')
if sys.flags.optimize:
    raise RuntimeError('Validation is disabled under -O/-OO or PYTHONOPTIMIZE; rerun without optimization.')

ROOT = Path(__file__).resolve().parent
def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

manifest = load(ROOT/'MANIFEST.json')
for item in manifest['files']:
    path = (ROOT/item['path']).resolve()
    assert path.is_relative_to(ROOT), 'Unsafe manifest path'
    data = path.read_bytes()
    assert len(data) == item['bytes'], 'Byte count mismatch: '+item['path']
    assert hashlib.sha256(data).hexdigest() == item['sha256'], 'Hash mismatch: '+item['path']
actual_files = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
assert actual_files == {x['path'] for x in manifest['files']} | {'MANIFEST.json'}, 'Unmanifested or missing file'
q = ROOT/'prontoqa_feasibility_20261010/qualification_01'
passes = [load(q/f'pass{i}_results.json') for i in (1,2)]
cores = [p['core'] for p in passes]
assert cores[0] == cores[1], 'Saved replay cores differ'
for i,c in enumerate(cores,1):
    journal = [json.loads(line) for line in (q/f'pass{i}_attempts.jsonl').read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    assert journal == c['attempts'], 'Journal/core mismatch'
    counts = Counter(row['status'] for row in journal)
    assert len(journal)==1574 and counts=={'returned':44,'rejected':1530}, 'Saved attempt-count mismatch'
    assert len(c['cases'])==44 and len({x['unique_key'] for x in c['cases']})==44
    assert all(x['pass'] for x in c['cases'])
    for cell in c['cells']:
        rows=[x for x in journal if (x['configuration'],x['depth'])==(cell['configuration'],cell['depth'])]
        assert len(rows)==cell['attempts']
        assert sum(x['status']=='returned' for x in rows)==cell['returned']
        for stream in cell['streams']:
            s=[x for x in rows if x['base_seed']==stream['base_seed']]
            assert len(s)==stream['attempts']
            assert sum(x['status']=='returned' for x in s)==stream['returned']
    fixtures=c['fixtures']['records']
    assert len(fixtures)==25
    assert all(all(r['actual'].get(k)==v for k,v in r['expected'].items()) for r in fixtures)
    assert len(c['matched_pairs'])==44 and all(p['pass'] for p in c['matched_pairs'])
    for pair in c['matched_pairs']:
        canonical=lambda x: json.dumps(x,sort_keys=True,separators=(',',':'))
        assert Counter(canonical(x) for x in pair['valid_context']) == Counter(canonical(x) for x in pair['invalid_context'])
        assert pair['context_word_bag_equal'] is True
        assert pair['invalid_score']['globally_entailed'] is True
        assert pair['valid_score']['first_unsupported'] is None
        assert pair['invalid_score']['first_unsupported'] is not None
    assert c['exhaustive']=={'comparisons':5120,'mismatches':[],'pass':True}
    assert c['gates']['supply'] is False
    assert 'STOP' in passes[i-1]['verdict']
print('PASS: public manifest and saved-record validation')
print('Each pass: 1574 attempts, 44 returns, 1530 rejections; combined: 3148; distinct cases: 44.')
print('Replay/journals agree; 25 fixture expectations and 44 matched pairs agree. Historical STOP preserved.')
print('5120 logical comparisons are aggregate-only; no entailment or generation was rerun.')
